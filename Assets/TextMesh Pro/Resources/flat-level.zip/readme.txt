You can find full project & download link in my Behance project.
It's Free mate

I originally designed the font for myself but then decided to share it. I edited the whole font and exported it as TTF files for comfortable use, It contains Light and Regular weights, there may be some errors in the font. but you're welcome to use it.

FLAT LEVEL is a unique sharp display font. It contains only all caps letters, numbers, and symbols. The font contains only English & Turkish languages.

https://www.behance.net/slarpec
https://www.instagram.com/slarpec/